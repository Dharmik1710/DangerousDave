use sdl2::rect::Rect;

pub struct Sprite {
    pub src_rect: Rect,
}
