use dangerous_dave::game;

fn main() {
    // Entry point of the program.
    // We delegate the core logic to `game::run()`.
    game::run();
}
